### Note

The documents are moved to [https://day.js.org](https://day.js.org).
